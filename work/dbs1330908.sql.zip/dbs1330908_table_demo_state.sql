
-- --------------------------------------------------------

--
-- Table structure for table `demo_state`
--

CREATE TABLE `demo_state` (
  `id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `demo_state`
--

INSERT INTO `demo_state` (`id`, `name`) VALUES
(1, 'zambia'),
(2, 'Malawi'),
(3, 'Angola'),
(4, 'Botswan');
